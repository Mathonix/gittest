#ifndef __IO_H__
#define __IO_H__
#include "main.h"
void configIO_Init(void);


#endif
