#ifndef __NVIC_H__
#define __NVIC_H__
#include "main.h"
void configNVIC_Init(void);
#endif
