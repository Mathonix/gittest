#ifndef __CAN_H__
#define __CAN_H__
#include "main.h"
void configCAN_Init(void);

#endif
