#ifndef __UART_H__
#define __UART_H__
#include "main.h"
void configUART_Init(void);
#endif
