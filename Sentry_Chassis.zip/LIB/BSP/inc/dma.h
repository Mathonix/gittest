#ifndef __DMA_H__
#define __DMA_H__
#include "main.h"
void configDMA_Init(void);

#endif
